/* Surprise Gift Box - main script.
   To change the default gift, edit the DEF object below (names, messages, photos). */
(()=>{
"use strict";
const $=s=>document.querySelector(s), KEY="surpriseGiftBox.v1";
const RM=matchMedia("(prefers-reduced-motion:reduce)").matches;
/* ---------- default content & photo art ---------- */
function art(a,b,kind){
  let s='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+a+'"/><stop offset="1" stop-color="'+b+'"/></linearGradient></defs><rect width="400" height="400" fill="url(#g)"/>';
  if(kind==0)s+='<circle cx="270" cy="170" r="60" fill="#fff3c4" opacity=".9"/><path d="M0 300Q100 220 200 290T400 260V400H0z" fill="#4a2a5e"/><path d="M0 340Q120 290 240 330T400 320V400H0z" fill="#2c1540"/>';
  if(kind==1){for(let i=0;i<40;i++)s+='<circle cx="'+(i*97%400)+'" cy="'+(i*53%260)+'" r="'+(1+i%3)+'" fill="#fff" opacity=".8"/>';s+='<circle cx="120" cy="120" r="46" fill="#fdf2cf"/><circle cx="140" cy="110" r="40" fill="'+a+'"/><path d="M0 330Q200 270 400 330V400H0z" fill="#0b0820"/>';}
  if(kind==2)s+='<circle cx="90" cy="110" r="40" fill="#fff0c0"/><path d="M0 240Q50 220 100 240T200 240T300 240T400 240V400H0z" fill="#2a7fa5" opacity=".85"/><path d="M0 290Q50 270 100 290T200 290T300 290T400 290V400H0z" fill="#16587a"/><path d="M0 340Q50 320 100 340T200 340T300 340T400 340V400H0z" fill="#0d3d57"/>';
  if(kind==3){s+='<rect y="300" width="400" height="100" fill="#2f6b45"/>';[70,150,230,310].forEach((x,i)=>{s+='<path d="M'+x+' 300V230" stroke="#2f6b45" stroke-width="5"/><circle cx="'+x+'" cy="218" r="22" fill="'+['#ff8fb1','#ffd36b','#ff6f91','#fff'][i]+'"/><circle cx="'+x+'" cy="218" r="8" fill="#ffb347"/>';});s+='<path d="M200 190c-30-22-44-38-44-52 0-10 8-18 18-18 11 0 21 6 26 14 5-8 15-14 26-14 10 0 18 8 18 18 0 14-14 30-44 52z" fill="#fff" opacity=".85" transform="translate(0 -60) scale(1 1)"/>';}
  return "data:image/svg+xml,"+encodeURIComponent(s+"</svg>");
}
const DEF={receiver:"Amelia",sender:"Daniel",
message:"Every day with you feels like unwrapping something wonderful.\nThank you for the laughter, the patience, and the quiet moments that mean the most.\nThis small surprise is my way of saying: you matter more than you know.",
letter:"Dear Amelia,\n\nThere are things I never say out loud, so I wrote them here. You make ordinary days feel golden, and you make the hard ones lighter just by being there.\n\nWhatever comes next, I hope you always remember how loved you are.\n\nForever yours,\nDaniel",
closing:"May every day ahead be as warm and bright as you make the world around you.",
theme:"aurora",title:"A Little Surprise For You!",
photos:[{src:"images/photo1.jpg",cap:"Your smile lights up every day"},{src:"images/photo2.jpg",cap:"A quiet day, just for you"},{src:"images/photo3.jpg",cap:"Like roses, you make life bloom"},{src:"images/photo4.jpg",cap:"Every moment with you is a gift"}]};
let cfg=load();
function load(){try{const j=JSON.parse(localStorage.getItem(KEY));if(j&&typeof j==="object")return Object.assign({},DEF,j);}catch(e){}return JSON.parse(JSON.stringify(DEF));}
function save(){try{localStorage.setItem(KEY,JSON.stringify(cfg));return true;}catch(e){return false;}}
/* ---------- render ---------- */
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function render(){
  document.documentElement.dataset.t=cfg.theme;
  $("#toName").textContent="Dear "+cfg.receiver+",";
  $("#fromName").textContent="With love, "+cfg.sender;
  $("#closing").textContent=cfg.closing+" — "+cfg.sender;
  const m=$("#msg");m.textContent="";let n=0;
  cfg.message.split(/(\s+)/).forEach(t=>{if(/^\s+$/.test(t)){m.append(t);return;}const s=document.createElement("span");s.className="w";s.textContent=t;s.style.animationDelay=(n++*70)+"ms";m.append(s);});
  $("#pols").innerHTML=cfg.photos.map((p,i)=>'<button class="pol" style="--r:'+(((i*37)%7)-3)+'deg" data-i="'+i+'" aria-label="Open photo: '+esc(p.cap)+'"><img src="'+p.src+'" alt="'+esc(p.cap)+'" loading="lazy"><span>'+esc(p.cap)+'</span></button>').join("");
  document.title="A surprise for "+cfg.receiver;$("#ttl").textContent=cfg.title;$("#wm").style.backgroundImage='url("'+cfg.photos[0].src+'")';
}
/* ---------- canvas: stars + confetti ---------- */
const bg=$("#bg"),fx=$("#fx"),bx=bg.getContext("2d"),fc=fx.getContext("2d");let W,H,stars=[],bits=[],DPR=Math.min(devicePixelRatio||1,2);
function size(){W=innerWidth;H=innerHeight;[bg,fx].forEach(c=>{c.width=W*DPR;c.height=H*DPR;});bx.setTransform(DPR,0,0,DPR,0,0);fc.setTransform(DPR,0,0,DPR,0,0);
  stars=Array.from({length:Math.round(Math.min(120,W*H/9000))},()=>({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1.6+.3,p:Math.random()*6.28,v:Math.random()*.25+.05,s:Math.random()<.2}));}
addEventListener("resize",size);size();
function heart(c,x,y,s){c.beginPath();c.moveTo(x,y+s*.3);c.bezierCurveTo(x,y,x-s,y,x-s,y+s*.35);c.bezierCurveTo(x-s,y+s*.8,x,y+s*1.0,x,y+s*1.3);c.bezierCurveTo(x,y+s*1.0,x+s,y+s*.8,x+s,y+s*.35);c.bezierCurveTo(x+s,y,x,y,x,y+s*.3);c.fill();}
function burst(x,y,n){if(RM)n=Math.min(n,25);const cols=["#f3cf94","#ff8fb1","#fff","#c9a7ff","#ffd36b"];
  for(let i=0;i<n;i++){const a=Math.random()*6.28,v=Math.random()*10+4;bits.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-7,g:.22,r:Math.random()*6.28,vr:(Math.random()-.5)*.4,s:Math.random()*8+5,c:cols[i%5],h:Math.random()<.4,l:1});}}
let t0=0,sh=[];function loop(t){requestAnimationFrame(loop);if(document.hidden)return;const dt=t-t0;t0=t;
  bx.clearRect(0,0,W,H);for(const s of stars){s.p+=.02;s.y-=s.v*.15;if(s.y<-5)s.y=H+5;const a=.35+.45*Math.sin(s.p);bx.globalAlpha=a;bx.fillStyle=s.s?"#f3cf94":"#fff";bx.beginPath();bx.arc(s.x,s.y,s.r,0,6.28);bx.fill();if(s.s&&!RM){bx.fillRect(s.x-s.r*4,s.y-.4,s.r*8,.8);bx.fillRect(s.x-.4,s.y-s.r*4,.8,s.r*8);}}
  if(!RM&&Math.random()<.006)sh.push({x:Math.random()*W*.8,y:Math.random()*H*.5,l:1});sh=sh.filter(s=>s.l>0);for(const s of sh){s.x+=11;s.y+=5;s.l-=.02;bx.globalAlpha=s.l;const g=bx.createLinearGradient(s.x,s.y,s.x-110,s.y-50);g.addColorStop(0,"#fff");g.addColorStop(1,"rgba(255,255,255,0)");bx.strokeStyle=g;bx.lineWidth=2;bx.beginPath();bx.moveTo(s.x,s.y);bx.lineTo(s.x-110,s.y-50);bx.stroke();}
  bx.globalAlpha=1;fc.clearRect(0,0,W,H);
  bits=bits.filter(b=>b.l>0&&b.y<H+30);for(const b of bits){b.vy+=b.g;b.vx*=.99;b.x+=b.vx;b.y+=b.vy;b.r+=b.vr;b.l-=.004;fc.globalAlpha=Math.max(b.l,0);fc.fillStyle=b.c;fc.save();fc.translate(b.x,b.y);fc.rotate(b.r);if(b.h)heart(fc,0,-b.s/2,b.s*.5);else fc.fillRect(-b.s/2,-b.s/4,b.s,b.s/2);fc.restore();}
  fc.globalAlpha=1;}
requestAnimationFrame(loop);
/* ---------- experience flow ---------- */
const stage=$("#stage");let opened=false;
function rain(){let k=0;const id=setInterval(()=>{burst(Math.random()*W,-10,14);if(++k>6)clearInterval(id);},260);}
function openGift(){
  if(opened)return;opened=true;stage.classList.add("open");$("#openBtn").disabled=true;
  const r=stage.getBoundingClientRect();
  setTimeout(()=>{burst(r.left+r.width/2,r.top+r.height*.45,150);if(!RM)rain();},500);
  setTimeout(()=>{$("#hero").classList.add("gone");document.body.classList.remove("lock");document.body.classList.add("revealed");observe();scrollTo({top:0,behavior:"auto"});},RM?900:2600);
}
$("#openBtn").onclick=openGift;$("#boxBtn").onclick=openGift;
function observe(){const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("in");if(e.target.classList.contains("card"))$("#msg").classList.add("in");if(e.target.classList.contains("heart")&&!e.target.dataset.b){e.target.dataset.b=1;burst(innerWidth/2,innerHeight/2,90);}}}),{threshold:.25});
  document.querySelectorAll(".rv").forEach(el=>{el.classList.remove("in");io.observe(el);});}
/* ---------- gallery ---------- */
let cur=0;const lb=$("#lb");
function show(i){cur=(i+cfg.photos.length)%cfg.photos.length;const p=cfg.photos[cur];$("#lbImg").src=p.src;$("#lbImg").alt=p.cap;$("#lbCap").textContent=p.cap;}
$("#pols").addEventListener("click",e=>{const b=e.target.closest(".pol");if(!b)return;show(+b.dataset.i);lb.showModal();});
$("#pols").addEventListener("pointermove",e=>{const b=e.target.closest(".pol");if(!b||e.pointerType==="touch"||RM)return;const r=b.getBoundingClientRect();b.style.setProperty("--ry",((e.clientX-r.left)/r.width-.5)*18+"deg");b.style.setProperty("--rx",-((e.clientY-r.top)/r.height-.5)*18+"deg");});
$("#pols").addEventListener("pointerout",e=>{const b=e.target.closest(".pol");if(b){b.style.removeProperty("--rx");b.style.removeProperty("--ry");}});
$("#lbX").onclick=()=>lb.close();$("#lbP").onclick=()=>show(cur-1);$("#lbN").onclick=()=>show(cur+1);
lb.addEventListener("click",e=>{if(e.target===lb||e.target.classList.contains("in-lb"))lb.close();});
lb.addEventListener("keydown",e=>{if(e.key==="ArrowLeft")show(cur-1);if(e.key==="ArrowRight")show(cur+1);});
/* ---------- envelope ---------- */
let tm;function typeText(el,txt){clearInterval(tm);el.textContent="";if(RM){el.textContent=txt;return;}let i=0;el.classList.add("typing");tm=setInterval(()=>{el.textContent=txt.slice(0,++i);if(i>=txt.length){clearInterval(tm);el.classList.remove("typing");}},32);}
$("#env").onclick=function(){if(this.classList.contains("open"))return;this.classList.add("open");this.setAttribute("aria-expanded","true");$("#envHint").textContent="Your secret letter";
  setTimeout(()=>{$("#letter").classList.add("show");typeText($("#letterTxt"),cfg.letter);$("#letter").scrollIntoView({behavior:RM?"auto":"smooth",block:"center"});burst(innerWidth/2,innerHeight*.5,40);},RM?100:1400);};
/* ---------- replay ---------- */
function reset(){clearInterval(tm);wmCur=-1;run++;document.body.classList.remove("clean");opened=false;stage.classList.remove("open");$("#openBtn").disabled=false;$("#env").classList.remove("open");$("#env").setAttribute("aria-expanded","false");$("#envHint").textContent="Tap the envelope to open it.";$("#letter").classList.remove("show");$("#letterTxt").textContent="";
  document.body.classList.remove("revealed");document.body.classList.add("lock");$("#hero").classList.remove("gone");scrollTo({top:0,behavior:"auto"});$("#msg").classList.remove("in");}
$("#replay").onclick=reset;
/* ---------- editor ---------- */
const ed=$("#ed");let draft;
function resize(file,cb){const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,640/Math.max(im.width,im.height)),c=document.createElement("canvas");c.width=im.width*k;c.height=im.height*k;c.getContext("2d").drawImage(im,0,0,c.width,c.height);cb(c.toDataURL("image/jpeg",.78));};im.src=r.result;};r.readAsDataURL(file);}
function drawPh(){$("#fPh").innerHTML="";draft.photos.forEach((p,i)=>{const d=document.createElement("div");d.className="prow";
  d.innerHTML='<img alt="" src="'+p.src+'"><input type="text" maxlength="60" aria-label="Caption for photo '+(i+1)+'" value="'+esc(p.cap)+'"><button class="mini" aria-label="Remove photo '+(i+1)+'">Remove</button><input class="pick" type="file" accept="image/*" aria-label="Replace photo '+(i+1)+'">';
  d.querySelector("input[type=text]").oninput=e=>p.cap=e.target.value;
  d.querySelector("button").onclick=()=>{if(draft.photos.length<2){$("#edNote").textContent="Keep at least one photo.";return;}draft.photos.splice(i,1);drawPh();};
  d.querySelector(".pick").onchange=e=>{const f=e.target.files[0];if(f)resize(f,u=>{p.src=u;drawPh();});};
  $("#fPh").append(d);});$("#addPh").disabled=draft.photos.length>=6;}
$("#custBtn").onclick=()=>{draft=JSON.parse(JSON.stringify(cfg));$("#fRec").value=draft.receiver;$("#fTit").value=draft.title;$("#fSen").value=draft.sender;$("#fMsg").value=draft.message;$("#fLet").value=draft.letter;$("#fClo").value=draft.closing;$("#fTh").value=draft.theme;$("#edNote").textContent="";drawPh();ed.showModal();};
$("#fTh").onchange=e=>document.documentElement.dataset.t=e.target.value;
$("#addPh").onclick=()=>{const inp=document.createElement("input");inp.type="file";inp.accept="image/*";inp.onchange=()=>{const f=inp.files[0];if(f&&draft.photos.length<6)resize(f,u=>{draft.photos.push({src:u,cap:"Add a caption"});drawPh();});};inp.click();};
$("#saveEd").onclick=()=>{Object.assign(draft,{receiver:$("#fRec").value.trim()||DEF.receiver,title:$("#fTit").value.trim()||DEF.title,sender:$("#fSen").value.trim()||DEF.sender,message:$("#fMsg").value.trim()||DEF.message,letter:$("#fLet").value.trim()||DEF.letter,closing:$("#fClo").value.trim()||DEF.closing,theme:$("#fTh").value});
  cfg=draft;const ok=save();render();ed.close();reset();if(!ok)alert("Saved for this visit only: the photos are too large for browser storage.");};
$("#resetEd").onclick=()=>{try{localStorage.removeItem(KEY);}catch(e){}cfg=JSON.parse(JSON.stringify(DEF));render();ed.close();reset();};
$("#closeEd").onclick=()=>{document.documentElement.dataset.t=cfg.theme;ed.close();};
function fit(){const h=innerHeight,w=innerWidth,k=Math.max(.45,Math.min(1.3,(h-(w<560?410:370))/300,(w-30)/300));stage.style.setProperty("--k",k.toFixed(2));stage.style.margin=(-150*(1-k)).toFixed(0)+"px 0";}
addEventListener("resize",fit);addEventListener("orientationchange",fit);fit();
let run=0;
/* auto-play: plays the whole surprise by itself, good for screen recording */
const ab=$("#autoBtn");if(ab)ab.onclick=()=>{const my=++run,w=ms=>new Promise(r=>setTimeout(r,ms));document.body.classList.add("clean");openGift();
  (async()=>{await w(3600);for(const id of ["reveal","gallery","secret"]){if(my!==run)return;$("#"+id).scrollIntoView({behavior:"smooth"});await w(id==="secret"?1800:6500);if(id==="secret"){$("#env").click();await w(1800+cfg.letter.length*32+2500);}}if(my!==run)return;$("#final").scrollIntoView({behavior:"smooth"});})();};
/* music: soft chime tune made in the browser (no files needed) */
let ac,mt,on=false,ni=0;const NT=[261.6,329.6,392,523.3,392,329.6,293.7,349.2,440,587.3,440,349.2];
function tick(){const t=ac.currentTime,o=ac.createOscillator(),g=ac.createGain();o.type="sine";o.frequency.value=NT[ni++%NT.length];g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.12,t+.05);g.gain.exponentialRampToValueAtTime(.001,t+1.4);o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+1.5);}
$("#mus").onclick=function(){try{if(!ac)ac=new(window.AudioContext||window.webkitAudioContext)();on=!on;if(on){ac.resume();tick();mt=setInterval(tick,420);}else clearInterval(mt);this.textContent=on?"♪ Music on":"♪ Music off";this.setAttribute("aria-pressed",on);}catch(e){}};
/* floating hearts + tap hearts */
if(false)setInterval(()=>{if(document.hidden||!document.body.classList.contains("revealed"))return;const s=document.createElement("span");s.className="fl";s.textContent=["♥","✦","♡","✧"][Math.random()*4|0];s.style.cssText="left:"+Math.random()*100+"vw;font-size:"+(14+Math.random()*22)+"px;color:"+(Math.random()<.5?"var(--rose)":"var(--gold)")+";--d:"+(7+Math.random()*6)+"s;--x:"+(Math.random()*80-40)+"px";document.body.append(s);setTimeout(()=>s.remove(),14000);},700);
addEventListener("click",e=>{if(document.body.classList.contains("revealed")&&!e.target.closest("button,dialog"))burst(e.clientX,e.clientY,14);});
/* a different watermark photo for each section */
let wmCur=-1;
function setWm(i){if(i===wmCur)return;wmCur=i;const w=$("#wm");w.classList.add("sw");setTimeout(()=>{w.style.backgroundImage='url("'+cfg.photos[i%cfg.photos.length].src+'")';w.classList.remove("sw");},RM?0:600);}
const secs=["reveal","gallery","secret","final"],so=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)setWm(secs.indexOf(e.target.id));}),{threshold:.5});
secs.forEach(id=>so.observe($("#"+id)));
/* wish */
const wi=$("#wish");if(wi)wi.onclick=function(){burst(innerWidth/2,innerHeight/2,120);this.textContent="✨ Your wish is on its way";this.disabled=true;setTimeout(()=>{this.textContent="✨ Make a wish";this.disabled=false;},5000);};
/* Instagram cards: makes a PNG picture you can post */
function img(src){return new Promise(r=>{const i=new Image();i.onload=()=>r(i);i.onerror=()=>r(null);i.src=src;});}
async function saveCard(w,h,name){
  const c=document.createElement("canvas");c.width=w;c.height=h;const x=c.getContext("2d"),cs=getComputedStyle(document.documentElement),v=n=>cs.getPropertyValue(n).trim();
  const g=x.createLinearGradient(0,0,w,h);g.addColorStop(0,v("--b2"));g.addColorStop(.6,v("--b1"));g.addColorStop(1,v("--b3"));x.fillStyle=g;x.fillRect(0,0,w,h);
  for(let i=0;i<100;i++){x.globalAlpha=.25+Math.random()*.6;x.fillStyle="#fff";x.beginPath();x.arc(Math.random()*w,Math.random()*h,Math.random()*2.4+.5,0,6.28);x.fill();}
  x.globalAlpha=1;const gl=x.createRadialGradient(w/2,h*.45,0,w/2,h*.45,w*.8);gl.addColorStop(0,"rgba(243,207,148,.28)");gl.addColorStop(1,"rgba(0,0,0,0)");x.fillStyle=gl;x.fillRect(0,0,w,h);
  x.textAlign="center";
  const wrap=(t,mx,y,lh)=>{let l="";for(const wd of t.split(/\s+/)){const tt=l+wd+" ";if(x.measureText(tt).width>mx&&l){x.fillText(l.trim(),w/2,y);y+=lh;l=wd+" ";}else l=tt;}x.fillText(l.trim(),w/2,y);return y;};
  x.fillStyle="#fff";x.font="600 "+w*.09+"px Georgia,serif";let y=wrap(cfg.title,w*.82,h*.11,w*.1);
  x.fillStyle=v("--gold");x.font="italic "+w*.06+"px Georgia,serif";x.fillText("for "+cfg.receiver,w/2,y+w*.09);
  const p=cfg.photos[0],im=await img(p.src),s=Math.min(w*.56,h*.3),pad=w*.025;
  x.save();x.translate(w/2,h*.47);x.rotate(-.05);x.shadowColor="rgba(0,0,0,.5)";x.shadowBlur=40;x.shadowOffsetY=18;x.fillStyle="#fffaf2";x.fillRect(-s/2-pad,-s/2-pad,s+pad*2,s+pad*3.2);x.shadowColor="transparent";
  if(im){const m=Math.min(im.width,im.height),sx=(im.width-m)/2,sy=(im.height-m)*.25;x.drawImage(im,sx,sy,m,m,-s/2,-s/2,s,s);}x.fillStyle="#3a2a36";x.font="italic "+w*.035+"px Georgia,serif";x.fillText(p.cap.slice(0,34),0,s/2+pad*2.2);x.restore();
  x.fillStyle="#fff";x.font="italic "+w*.045+"px Georgia,serif";const first=cfg.message.split(/(?<=[.!?])\s/)[0].slice(0,140);
  const ye=wrap(first,w*.8,h*.47+s/2+w*.14,w*.062);
  x.fillStyle=v("--gold");x.font="600 "+w*.045+"px Georgia,serif";x.fillText("With love, "+cfg.sender,w/2,Math.min(ye+w*.12,h-w*.12));
  x.fillStyle=v("--rose");heart(x,w/2,h-w*.1,w*.025);
  const b=await new Promise(r=>c.toBlob(r,"image/png")),f=new File([b],name,{type:"image/png"});
  try{if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f]});return;}}catch(e){if(e.name==="AbortError")return;}
  const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);}
const c9=$("#card9"),c4=$("#card4");if(c9)c9.onclick=()=>saveCard(1080,1920,"gift-story.png");
if(c4)c4.onclick=()=>saveCard(1080,1350,"gift-post.png");
/* share */
const sh2=$("#share");if(sh2)sh2.onclick=async function(){const d={title:document.title,text:"Open your surprise gift 🎁",url:location.href};try{if(navigator.share)await navigator.share(d);else{await navigator.clipboard.writeText(d.url);this.textContent="Link copied ✓";}}catch(e){}};
render();
})();
